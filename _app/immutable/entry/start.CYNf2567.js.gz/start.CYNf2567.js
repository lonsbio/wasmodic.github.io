import{l as o,a as r}from"../chunks/2lx8QW0x.js";export{o as load_css,r as start};
