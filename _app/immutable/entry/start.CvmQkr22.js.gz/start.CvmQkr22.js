import{l as o,a as r}from"../chunks/1nkzE8Sl.js";export{o as load_css,r as start};
